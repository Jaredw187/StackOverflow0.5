# Project3Group3
super awesome fun stuff

# Resources Used
= Script for updating footer copyright year - http://updateyourfooter.com
= CSS to push footer to bottom of screen - http://cssreset.com/how-to-keep-footer-at-bottom-of-page-with-css/
